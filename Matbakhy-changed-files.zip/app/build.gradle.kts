plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.legalvault.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.matbakhy.app"
        minSdk = 29
        targetSdk = 34
        // يزيد تلقائياً مع كل بناء على GitHub، عشان التحديث يتثبت فوق القديم
        versionCode = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1
        versionName = "1.0"
    }

    signingConfigs {
        create("release") {
            val pw = System.getenv("KEYSTORE_PASSWORD")
            val ks = file("${rootDir}/keystore/release.jks")
            if (pw != null && ks.exists()) {
                storeFile = ks
                storePassword = pw
                keyAlias = "legalvault"
                keyPassword = pw
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    lint { checkReleaseBuilds = false }
}

dependencies {
    implementation("androidx.activity:activity-ktx:1.9.2")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.webkit:webkit:1.11.0")
}

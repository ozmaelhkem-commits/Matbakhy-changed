package com.legalvault.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.CancellationSignal
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyPermanentlyInvalidatedException
import android.security.keystore.KeyProperties
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.Base64
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewFeature
import java.io.File
import java.io.OutputStream

class MainActivity : ComponentActivity() {

    private lateinit var web: WebView
    private var chooserCb: ValueCallback<Array<Uri>>? = null

    private val chooser =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            chooserCb?.onReceiveValue(
                WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data)
            )
            chooserCb = null
        }
    private var pendingPerm: PermissionRequest? = null
    private val camPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            val r = pendingPerm
            pendingPerm = null
            if (ok) r?.grant(arrayOf(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) else r?.deny()
        }

    private val pdfDir by lazy { File(cacheDir, "pdf").apply { mkdirs() } }
    private val outDir by lazy { File(cacheDir, "out").apply { mkdirs() } }

    private fun wipe(d: File) { d.listFiles()?.forEach { it.delete() } }
    private fun toast(s: String) = runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        wipe(pdfDir); wipe(outDir)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/pdfcache/", WebViewAssetLoader.InternalStoragePathHandler(this, pdfDir))
            .build()

        web = WebView(this)
        setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            setSupportZoom(false)
        }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(web.settings, false)
        }
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? = loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest) = true
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    if (request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) {
                        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                            request.grant(arrayOf(PermissionRequest.RESOURCE_VIDEO_CAPTURE))
                        } else {
                            pendingPerm = request
                            camPerm.launch(Manifest.permission.CAMERA)
                        }
                    } else request.deny()
                }
            }

            override fun onShowFileChooser(
                w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams
            ): Boolean {
                chooserCb?.onReceiveValue(null)
                chooserCb = cb
                return try { chooser.launch(p.createIntent()); true }
                catch (e: Exception) { chooserCb = null; false }
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("window.__back&&window.__back()") { r ->
                    if (r != "true") { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
                }
            }
        })

        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    override fun onDestroy() {
        wipe(pdfDir); wipe(outDir)
        web.destroy()
        super.onDestroy()
    }

    private fun deliver(f: File, name: String, mime: String, mode: String) {
        try {
            if (mode == "save") {
                val v = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
                if (uri == null) { toast("تعذّر الحفظ"); return }
                contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
                toast("اتحفظ في مجلد التنزيلات")
            } else {
                val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
                val i = if (mode == "share")
                    Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uri)
                else Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                i.clipData = ClipData.newRawUri("", uri)
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(Intent.createChooser(i, null))
            }
        } catch (e: Exception) {
            toast("تعذّر تنفيذ العملية، أو مفيش تطبيق يفتح الملف ده")
        } finally {
            if (mode == "save") f.delete()
        }
    }

    // ---------- فتح بالبصمة (Android Keystore) ----------
    // الرمز السري بيتخزن مشفّر بمفتاح محمي بالبصمة، ومابيتفكش غير بعد التحقق منها.
    private val bioAlias = "lv_bio_key"
    private fun bioPrefs() = getSharedPreferences("bio", MODE_PRIVATE)
    private fun ks(): KeyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }

    private fun wipeBio() {
        try { ks().deleteEntry(bioAlias) } catch (_: Exception) {}
        bioPrefs().edit().clear().apply()
    }

    private fun newBioKey(): SecretKey {
        try { ks().deleteEntry(bioAlias) } catch (_: Exception) {}
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(
            KeyGenParameterSpec.Builder(
                bioAlias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setUserAuthenticationRequired(true)
                .setInvalidatedByBiometricEnrollment(true)
                .build()
        )
        return g.generateKey()
    }

    private fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }
    private fun jq(s: String): String = JSONObject.quote(s)

    private fun bioAsk(cipher: Cipher, title: String, ok: (Cipher) -> Unit, fail: (String?) -> Unit) {
        val prompt = BiometricPrompt.Builder(this)
            .setTitle(title)
            .setNegativeButton("إلغاء", mainExecutor) { _, _ -> fail(null) }
            .build()
        prompt.authenticate(
            BiometricPrompt.CryptoObject(cipher), CancellationSignal(), mainExecutor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    val c = result.cryptoObject?.cipher
                    if (c != null) ok(c) else fail("تعذّر التحقق")
                }

                override fun onAuthenticationError(code: Int, msg: CharSequence?) {
                    // 5 = ملغي، 10 = المستخدم لغى، 13 = زر الإلغاء
                    fail(if (code == 5 || code == 10 || code == 13) null else msg?.toString())
                }
            })
    }

    inner class Bridge {
        @Volatile private var out: OutputStream? = null
        @Volatile private var tmp: File? = null
        private var name = "file"
        private var mime = "application/octet-stream"
        private var mode = "save"

        private fun start(n: String, m: String, md: String) {
            try { out?.close() } catch (_: Exception) {}
            name = n.replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "file" }
            mime = m; mode = md
            val f = File(outDir, name)
            tmp = f; out = f.outputStream()
        }

        /** حفظ / مشاركة / فتح ملف: begin ثم chunk (base64) عدة مرات ثم end */
        @JavascriptInterface fun begin(n: String, m: String, md: String) = start(n, m, md)

        @JavascriptInterface fun chunk(b64: String) { out?.write(Base64.decode(b64, Base64.DEFAULT)) }

        @JavascriptInterface fun end() {
            try { out?.close() } catch (_: Exception) {}
            out = null
            val f = tmp ?: return
            val n = name; val m = mime; val md = mode
            Thread { deliver(f, n, m, md) }.start()
        }

        /** عرض PDF داخل التطبيق: صفحاته بتتحول لصور مؤقتة وبتتمسح بعد الإغلاق */
        @JavascriptInterface fun pdfBegin() = start("doc.pdf", "application/pdf", "pdf")

        @JavascriptInterface fun pdfEnd(): String {
            try { out?.close() } catch (_: Exception) {}
            out = null
            val f = tmp ?: return "0"
            return try {
                wipe(pdfDir)
                val pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
                PdfRenderer(pfd).use { r ->
                    val n = minOf(r.pageCount, 40)
                    for (i in 0 until n) {
                        r.openPage(i).use { p ->
                            val w = 1100
                            val h = (w.toFloat() * p.height / p.width).toInt().coerceAtLeast(1)
                            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                            bmp.eraseColor(Color.WHITE)
                            p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            File(pdfDir, "p$i.jpg").outputStream().use {
                                bmp.compress(Bitmap.CompressFormat.JPEG, 85, it)
                            }
                            bmp.recycle()
                        }
                    }
                    n.toString()
                }
            } catch (e: Exception) {
                "0"
            } finally {
                f.delete()
            }
        }

        @JavascriptInterface fun pdfClear() { wipe(pdfDir) }

        @JavascriptInterface fun setReminders(json: String) { Reminders.save(applicationContext, json) }

        @JavascriptInterface fun setSecure(on: Boolean) {
            runOnUiThread {
                if (on) window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
            }
        }

        @JavascriptInterface fun bioAvailable(): Boolean = try {
            val m = getSystemService(BiometricManager::class.java)
            if (Build.VERSION.SDK_INT >= 30)
                m.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS
            else m.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS
        } catch (e: Exception) { false }

        @JavascriptInterface fun bioEnabled(): Boolean = bioPrefs().contains("ct")

        @JavascriptInterface fun bioClear() { wipeBio() }

        @JavascriptInterface fun bioEnroll(pin: String) {
            runOnUiThread {
                try {
                    val c = Cipher.getInstance("AES/GCM/NoPadding")
                    c.init(Cipher.ENCRYPT_MODE, newBioKey())
                    bioAsk(c, "تفعيل البصمة", { ci ->
                        try {
                            val ct = ci.doFinal(pin.toByteArray(Charsets.UTF_8))
                            bioPrefs().edit()
                                .putString("iv", Base64.encodeToString(ci.iv, Base64.NO_WRAP))
                                .putString("ct", Base64.encodeToString(ct, Base64.NO_WRAP))
                                .apply()
                            js("window.__bioDone(true," + jq("✅ البصمة اتفعّلت.") + ")")
                        } catch (e: Exception) {
                            wipeBio(); js("window.__bioDone(false," + jq("تعذّر التفعيل.") + ")")
                        }
                    }, { m ->
                        wipeBio(); js("window.__bioDone(false," + jq(m ?: "اتلغى التفعيل.") + ")")
                    })
                } catch (e: Exception) {
                    wipeBio(); js("window.__bioDone(false," + jq("الجهاز مش مجهّز للبصمة.") + ")")
                }
            }
        }

        @JavascriptInterface fun bioUnlock() {
            runOnUiThread {
                try {
                    val p = bioPrefs()
                    val iv = Base64.decode(p.getString("iv", "") ?: "", Base64.NO_WRAP)
                    val ct = Base64.decode(p.getString("ct", "") ?: "", Base64.NO_WRAP)
                    val key = ks().getKey(bioAlias, null) as? SecretKey
                    if (key == null) {
                        js("window.__bioFail(" + jq("البصمة اتلغت. افتح بالرمز.") + ")")
                        return@runOnUiThread
                    }
                    val c = Cipher.getInstance("AES/GCM/NoPadding")
                    c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
                    bioAsk(c, "افتح الخزنة", { ci ->
                        try {
                            val pin = String(ci.doFinal(ct), Charsets.UTF_8)
                            js("window.__bioPin(" + jq(pin) + ")")
                        } catch (e: Exception) {
                            js("window.__bioFail(" + jq("تعذّر فك القفل. افتح بالرمز.") + ")")
                        }
                    }, { m -> js("window.__bioFail(" + jq(m ?: "") + ")") })
                } catch (e: KeyPermanentlyInvalidatedException) {
                    wipeBio()
                    js("window.__bioFail(" + jq("اتغيّرت بصماتك. افتح بالرمز وفعّل البصمة تاني.") + ")")
                } catch (e: Exception) {
                    js("window.__bioFail(" + jq("تعذّر استخدام البصمة.") + ")")
                }
            }
        }

        @JavascriptInterface fun openUrl(u: String) {
            if (!u.startsWith("https://")) return
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            catch (_: Exception) { toast("مفيش متصفح يفتح الرابط") }
        }
    }
}

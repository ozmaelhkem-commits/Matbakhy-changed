package com.legalvault.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import org.json.JSONArray

object Reminders {
    private const val PREF = "rem"

    fun save(c: Context, json: String) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("list", json).apply()
        schedule(c)
    }

    private fun pi(c: Context, id: String, title: String, text: String): PendingIntent {
        val i = Intent(c, ReminderReceiver::class.java)
            .putExtra("id", id).putExtra("title", title).putExtra("text", text)
        return PendingIntent.getBroadcast(
            c, id.hashCode(), i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    fun schedule(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java)
        val prefs = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        prefs.getString("ids", "")!!.split(",").filter { it.isNotEmpty() }
            .forEach { am.cancel(pi(c, it, "", "")) }

        val arr = try { JSONArray(prefs.getString("list", "[]")) } catch (e: Exception) { JSONArray() }
        val now = System.currentTimeMillis()
        val ids = ArrayList<String>()
        for (i in 0 until minOf(arr.length(), 400)) {
            val o = arr.getJSONObject(i)
            val t = o.getLong("t")
            if (t <= now) continue
            val id = o.getString("id")
            am.setAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP, t, pi(c, id, o.getString("title"), o.getString("text"))
            )
            ids.add(id)
        }
        prefs.edit().putString("ids", ids.joinToString(",")).apply()
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("exp", "تنبيهات انتهاء المستندات", NotificationManager.IMPORTANCE_HIGH)
        )
        val open = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(c, "exp")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(i.getStringExtra("title"))
            .setContentText(i.getStringExtra("text"))
            .setContentIntent(open)
            .setAutoCancel(true)
            .setVisibility(Notification.VISIBILITY_PRIVATE)
            .build()
        nm.notify((i.getStringExtra("id") ?: "").hashCode(), n)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Reminders.schedule(c)
    }
}
